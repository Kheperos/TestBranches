<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <link   href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
<div class="container">
    <div class="row">
    </div>
    <div class="row">
        <table class="table table-striped table-bordered">
            <thead>
            <tr>
                <th>Branch</th>
            </tr>
            </thead>
            <tbody>
            <?php
            include 'database.php';
            $pdo = Database::connect();

            $sql = 'SELECT * FROM `Branches` ORDER BY BranchName';
            foreach ($pdo->query($sql) as $row) {
                echo '<tr>';
                echo '<td>'. $row[0] . '</td>';
                echo '</tr>';
            }


            Database::disconnect();
            ?>

            </tbody>
        </table>
    </div>
</div> <!-- /container -->
<h3>

    <form action="demo_form.php" method="post" id="github">
        Name:<input type="text" name="name">
        <br>
        Branch:
        <?php
        $strToEcho = '<select name="branchlist">';
        $pdo = Database::connect();
        $sql = 'SELECT * FROM `Branches` ORDER BY BranchName';
        foreach ($pdo->query($sql) as $row) {
            $strToEcho .= chr(10) . '<option>' . $row[0] . '</option>';
            }
            $strToEcho .= chr(10) . '<select>';
                echo $strToEcho;
        ?>
        <br>
        Folder:<input type="text" name="folder">
        <br>
        <input type="submit">
    </form>

</h3>

</body>

</html>