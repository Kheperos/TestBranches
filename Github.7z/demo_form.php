<html>
<body>

Welcome <?php echo $_POST["name"]; ?><br>
Your folder: <?php echo $_POST["folder"]; ?>
<br>
Your branch: <?php echo $_POST['branchlist']; ?>

<h3>Executing Newhost.sh</h3>
<?php
//exec('Newhost.sh TBI');
?>

</body>
</html>